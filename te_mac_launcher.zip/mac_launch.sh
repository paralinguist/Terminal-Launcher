#!/bin/sh
SCRIPT_DIR=`pwd`
open mac_status.command &
open mac_command.command &
open mac_game.command &
